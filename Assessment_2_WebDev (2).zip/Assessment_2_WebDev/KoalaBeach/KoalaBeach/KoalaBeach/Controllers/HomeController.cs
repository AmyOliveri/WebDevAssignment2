﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using KoalaBeach.Models;
//using KoalaBeach.Models.ViewModels;

namespace KoalaBeach.Controllers
{
    public class HomeController : Controller
    {
        private IStoreRepository repository;

        public HomeController(IStoreRepository repo)
        {
            repository = repo;
        }

        public IActionResult Test()
            => View(repository.Products);

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Catalog()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult RegistrationForm() {
            return View();
        }

        [Route("/Catalog/{type}")]
        [Route("/Catalog/{type}/{category}")]
        public ViewResult Catalog(String type, string category)
        {
            ViewBag.Type = type;            // men, women, sale
            ViewBag.Category = category;    // shirts, caps, shoes etc

            IEnumerable<Product> products = repository.Products
                   .Where(p => (category == null || p.Category == category) && p.SubCategory == type)
                   .OrderBy(p => p.ProductID);

            return View(products);
        }
    }
}
