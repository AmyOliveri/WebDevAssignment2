﻿using Microsoft.AspNetCore.Mvc;
using KoalaBeach.Models;
namespace KoalaBeach.Controllers
{
    public class OrderController : Controller
    {
        public ViewResult Checkout() => View(new Order());
    }
}