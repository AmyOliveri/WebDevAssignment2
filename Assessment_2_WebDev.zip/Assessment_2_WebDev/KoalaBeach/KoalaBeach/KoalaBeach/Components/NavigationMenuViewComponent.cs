﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using KoalaBeach.Models;

namespace KoalaBeach.Components
{
    public class NavigationMenuViewComponent : ViewComponent
    {
        private IStoreRepository repository;

        public NavigationMenuViewComponent(IStoreRepository repo)
        {
            repository = repo;
        }
        public IViewComponentResult Invoke()
        {
            ViewBag.SelectedCategory = RouteData?.Values["category"];
            //string type = RouteData?.Values["type"].ToString();

            return View(repository.Products
               //.Where(x => x.SubCategory == type)
               .Select(x => x.Category)
               .Distinct()
               .OrderBy(x => x));
        }
    }
}

