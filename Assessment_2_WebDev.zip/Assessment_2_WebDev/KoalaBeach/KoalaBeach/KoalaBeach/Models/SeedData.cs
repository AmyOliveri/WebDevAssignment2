﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace KoalaBeach.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            StoreDbContext context = app.ApplicationServices
                .CreateScope().ServiceProvider.GetRequiredService<StoreDbContext>();
            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }
            if (!context.Products.Any())
            {
                context.Products.AddRange(
                    new Product
                    {
                        Name = "T Shirt",
                        Description = "Groovy T Shirt",
                        Category = "Shirt",
                        SubCategory = "Men",
                        Price = 15
                    },
                    new Product
                    {
                        Name = "Single Top",
                        Description = "Singlet style top",
                        Category = "Shirt",
                        SubCategory = "Men",
                        Price = 20
                    },
                    new Product { 
                        Name = "Singlet",
                        Description = "Strappy singlet for summer's days",
                        Category = "Shirt",
                        SubCategory = "Women",
                        Price = 15,
                    },
                    new Product {
                        Name = "Dress",
                        Description = "Short and perfect for summer",
                        Category = "Dress",
                        SubCategory = "Women",
                        Price = 40,
                    },
                    new Product { 
                        Name = "Cap",
                        Description = "Sun safe and fashionable",
                        Category = "Hat",
                        SubCategory = "Hat",
                        Price = 10,
                    }
                );
                context.SaveChanges();
            }
        }
    }
}

